Find My Mutual Fund — ICICI Prudential September 2026 portfolio files

This archive contains 45 individual workbooks selected by matching scheme names
against the current AMFI review-only candidate list for the product's stated v1
categories (ELSS, flexi/large/mid/multi/small cap, PSU, equity index and
sectoral/thematic). Scheme-name matching was used to reduce the original 151
workbooks; a manually checked alias maps "ICICI Prudential Large Cap Fund
(erstwhile Bluechip Fund)" to "ICICI Prudential Large Cap Fund.xlsx".

These are input disclosures, not verified fund records. The processor is designed
to keep include_v1=false until scheme identity, category, plan/option and
sector mappings have been reviewed. This ZIP should be uploaded unchanged into
the repository's data/raw/ folder for parsing tests.
